// src/youtubeAPI.js
const API_KEY = "AIzaSyDnRqu0ugf4b3fk65MS43sU_Z8ZNwLuetg"; // Replace with your key
const BASE_URL = "https://www.googleapis.com/youtube/v3/search";

const getYoutubeVideos = async (query, maxResults = 5) => {
  try {
    const response = await fetch(
      `${BASE_URL}?part=snippet&type=video&videoDuration=medium&maxResults=${maxResults}&q=${encodeURIComponent(
        query
      )}&key=${API_KEY}`
    );
    const data = await response.json();
    return data.items;
  } catch (error) {
    console.error("Error fetching videos:", error);
    return [];
  }
};

export default getYoutubeVideos;
