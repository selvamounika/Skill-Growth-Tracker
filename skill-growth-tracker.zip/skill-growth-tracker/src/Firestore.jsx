import { firestore } from './Firebase';
import { collection, doc, getDocs, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { getAuth } from 'firebase/auth'; // ✅ Import Firebase Auth

// 🔹 Utility to get current user ID
const getCurrentUserId = () => {
  const auth = getAuth();
  const user = auth.currentUser;
  if (!user) throw new Error("User not logged in");
  return user.uid;
};

// ✅ Fetch all tests taken by the logged-in user
export const getUserTests = async () => {
  try {
    const userId = getCurrentUserId();
    const testRef = collection(firestore, 'users', userId, 'tests');
    const snapshot = await getDocs(testRef);
    return snapshot.docs.map(doc => ({
      testId: doc.id,
      ...doc.data()
    }));
  } catch (error) {
    console.error('Error fetching user tests:', error);
    return [];
  }
};

// ✅ Store test results without insights initially
export const storeTestResults = async (testData) => {
  try {
    const userId = getCurrentUserId();

    // Let Firestore auto-generate a new doc ID
    const testRef = doc(collection(firestore, 'users', userId, 'tests'));

    const testWithId = {
      ...testData,
      testId: testRef.id, // Add Firestore-generated testId to the data
      insights: null,
    };

    await setDoc(testRef, testWithId);
    console.log('Test results stored successfully with ID:', testRef.id);
  } catch (error) {
    console.error('Error storing test results:', error);
  }
};


// ✅ Fetch details of a specific test
export const getTestDetails = async (testId) => {
  try {
    const userId = getCurrentUserId();
    const testDocRef = doc(firestore, 'users', userId, 'tests', testId);
    const testDocSnap = await getDoc(testDocRef);
    return testDocSnap.exists() ? testDocSnap.data() : null;
  } catch (error) {
    console.error('Error fetching test details:', error);
    return null;
  }
};

// ✅ Update the test document with insights after they're generated
export const updateTestWithInsights = async (testId, insights) => {
  try {
    const userId = getCurrentUserId();
    const testRef = doc(firestore, 'users', userId, 'tests', testId);

    // If insights are undefined, set a fallback or empty insights
    if (!insights) {
      insights = {
        incorrectAnswers: "No insights available at the moment.",
        roadmap: "No roadmap generated.",
        techniques: "No techniques provided.",
        jobTips: "No job tips provided.",
        motivation: "Keep trying, you'll improve!"
      };
    }

    // Update the test document with the generated insights
    console.log("Updating test with ID:", testId, "with insights:", insights);
    await updateDoc(testRef, {
      insights: insights,  // The AI-generated insights object
    });

    console.log('Insights added successfully.');
  } catch (error) {
    console.error('Error updating insights:', error);
  }
};

// ✅ Handle storing AI-generated insights from /insights page
export const storeAiInsights = async (testId, aiInsights) => {
  await updateTestWithInsights(testId, aiInsights);
};