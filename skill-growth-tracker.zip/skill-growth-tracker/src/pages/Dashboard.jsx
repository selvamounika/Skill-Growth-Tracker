import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { getUserTests } from "../Firestore";
import Navbar from "../components/Navbar";
import "../rstyles.css";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  BarChart, Bar, Cell
} from "recharts";
import getYoutubeVideos from "../YoutubeAPI";

const Dashboard = () => {
  const navigate = useNavigate();
  const [tests, setTests] = useState([]);
  const [topDomain, setTopDomain] = useState("");
  const [quote, setQuote] = useState("🔥 Progress is progress, no matter how small. Keep going!");
  const [perfectTests, setPerfectTests] = useState([]);
  const [videoSuggestions, setVideoSuggestions] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const fetchedTests = await getUserTests();
      setTests(fetchedTests);

      const perfectScoreTests = fetchedTests.filter(test => test.score === test.totalQuestions);
      setPerfectTests(perfectScoreTests);

      const domainCount = {};
      fetchedTests.forEach(test => {
        domainCount[test.domain] = (domainCount[test.domain] || 0) + 1;
      });
      const sortedDomains = Object.entries(domainCount).sort((a, b) => b[1] - a[1]);
      const top = sortedDomains[0]?.[0] || "Not enough data";
      setTopDomain(top);

      const domainTopicStats = {};
      fetchedTests.forEach((test) => {
        if (test.domain === top) {
          const topic = test.topic;
          if (!domainTopicStats[topic]) {
            domainTopicStats[topic] = { attempts: 0, correct: 0 };
          }
          domainTopicStats[topic].attempts += test.totalQuestions;
          domainTopicStats[topic].correct += test.score;
        }
      });

      const weakestTopicEntry = Object.entries(domainTopicStats)
        .map(([topic, data]) => ({
          topic,
          accuracy: (data.correct / data.attempts) * 100
        }))
        .sort((a, b) => a.accuracy - b.accuracy)[0];

      if (weakestTopicEntry) {
        const query = `${top} ${weakestTopicEntry.topic} tutorial`;
        const videos = await getYoutubeVideos(query);
        setVideoSuggestions(videos);
      }
    };

    fetchData();
  }, []);

  const testsByDomain = tests.reduce((acc, test) => {
    if (!acc[test.domain]) acc[test.domain] = [];
    acc[test.domain].push({
      topic: test.topic,
      score: test.score,
      topicIndex: acc[test.domain].length + 1,
    });
    return acc;
  }, {});

  const chartColors = ["#8884d8", "#82ca9d", "#ffc658", "#ff8042", "#00C49F"];

  const topDomainTests = tests.filter(test => test.domain === topDomain);
  const topicStats = {};
  topDomainTests.forEach((test) => {
    const topic = test.topic;
    if (!topicStats[topic]) {
      topicStats[topic] = { attempts: 0, correct: 0 };
    }
    topicStats[topic].attempts += test.totalQuestions;
    topicStats[topic].correct += test.score;
  });

  const topicData = Object.entries(topicStats).map(([topic, data]) => {
    const accuracy = (data.correct / data.attempts) * 100;
    let strengthColor = "#ff4d4f";
    if (accuracy >= 80) strengthColor = "#52c41a";
    else if (accuracy >= 50) strengthColor = "#faad14";

    return {
      topic,
      accuracy: accuracy.toFixed(2),
      attempts: data.attempts,
      color: strengthColor,
    };
  });

  return (
    <div className="dashboard-container">
      <Navbar />
      <div className="dashboard-content">
        <h1 className="dashboard-title">👋 Welcome to UpSkillX</h1>
        <p className="dashboard-subtext">Track your skill growth and level up your future!</p>

        <div className="motivation-quote">
          <em>{quote}</em>
        </div>

        <div className="dashboard-buttons">
          <button className="btn primary" onClick={() => navigate("/tests")}>🚀 Take a Test</button>
          <button className="btn submit" onClick={() => navigate("/progress")}>📊 See My Progress</button>
        </div>

        <div className="snapshot-section">
          <div className="snapshot-card">
            <h3>🧠 Skill Rating</h3>
            <p>{tests.length > 0 ? "Intermediate" : "Newbie"}</p>
          </div>
          <div className="snapshot-card">
            <h3>📈 Tests Taken</h3>
            <p>{tests.length}</p>
          </div>
          <div className="snapshot-card">
            <h3>🏆 Top Domain</h3>
            <p>{topDomain}</p>
          </div>
        </div>

        {perfectTests.length > 0 && (
          <div className="badges-section">
            <h2>🏅 Badges for Perfect Scores</h2>
            <div className="badges-list">
              {perfectTests.map((test, index) => (
                <div className="badge" key={index}>
                  <h4>{test.topic}</h4>
                  <p>🏆 Perfect Score!</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {topicData.length > 0 && (
          <div className="topic-strength-section">
            <h2>📊 Strength Tracker - {topDomain}</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={topicData} layout="vertical" margin={{ top: 20, right: 30, left: 100, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" domain={[0, 100]} label={{ value: "Accuracy (%)", position: "insideBottomRight", offset: -5 }} />
                <YAxis type="category" dataKey="topic" width={150} tick={{ fontSize: 12 }} interval={0} />
                <Tooltip />
                <Bar dataKey="accuracy">
                  {topicData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {Object.entries(testsByDomain).map(([domain, data], index) => (
          <div className="performance-chart" key={domain}>
            <h2>📚 {domain} - Topic vs Score</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="topicIndex" tickFormatter={(idx) => data[idx - 1]?.topic || `#${idx}`} />
                <YAxis domain={[0, 20]} />
                <Tooltip
                  formatter={(value, name) => [value, name === "score" ? "Score" : "Topic"]}
                  labelFormatter={(label) => data[label - 1]?.topic || ""}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="score"
                  stroke={chartColors[index % chartColors.length]}
                  activeDot={{ r: 8 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        ))}

        {videoSuggestions.length > 0 && (
          <div className="video-section">
            <h2>🎥 Recommended YouTube Videos</h2>
            <div className="video-grid">
              {videoSuggestions.map((video, idx) => (
                <div className="video-card" key={idx}>
                  <a href={`https://www.youtube.com/watch?v=${video.id.videoId}`} target="_blank" rel="noopener noreferrer">
                    <img src={video.snippet.thumbnails.medium.url} alt={video.snippet.title} />
                    <h4>{video.snippet.title}</h4>
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}

        {tests.length > 0 && (
          <div className="suggested-action">
            <h2>✨ Suggested Next Step</h2>
            <p>Based on your top domain <strong>{topDomain}</strong>, you can explore more advanced challenges!</p>
            <button className="btn secondary" onClick={() => navigate("/tests")}>
              Take a Practice Test
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
