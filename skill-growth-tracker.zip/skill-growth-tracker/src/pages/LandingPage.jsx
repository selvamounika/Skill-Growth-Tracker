import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

function LandingPage() {
  const navigate = useNavigate();
  const allImages = [
    "/student1.jpg", "/student2.jpg", "/student3.jpg",
    "/student1.jpg", "/student2.jpg", "/student3.jpg"
  ];
  
  const [randomImages, setRandomImages] = useState([]);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const shuffled = [...allImages].sort(() => 0.5 - Math.random());
    setRandomImages(shuffled);
  }, []);

  // Detect when "Why Choose UpSkillX" is in view
  useEffect(() => {
    const handleScroll = () => {
      const section = document.getElementById("whyChoose");
      if (section) {
        const rect = section.getBoundingClientRect();
        if (rect.top < window.innerHeight * 0.75) {
          setIsVisible(true);
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 3,
    autoplay: true,
    autoplaySpeed: 3000,
    arrows: true,
    responsive: [
      { breakpoint: 768, settings: { slidesToShow: 2, slidesToScroll: 2 } },
      { breakpoint: 480, settings: { slidesToShow: 1, slidesToScroll: 1 } }
    ]
  };

  return (
    <div style={styles.container}>
      {/* Hero Section */}
      <section style={styles.heroSection}>
        <div style={styles.overlay}>
          <h1 style={styles.heroTitle}>Start Your Learning Journey with UpSkillX</h1>
          <p style={styles.heroSubtitle}><b>From zero to hero – One skill at a time! 🏆🚀 #LevelUpWithUpSkillX.</b></p>
          <div style={styles.buttonContainer}>
            <button style={styles.glowButton} onClick={() => navigate("/signup")}>Sign Up</button>
            <button style={styles.glowButton} onClick={() => navigate("/login")}>Log In</button>
          </div>
        </div>
        <img src="/student3.jpg" alt="Learning" style={styles.heroImage} />
      </section>

      {/* Why Choose UpSkillX - Animated Section */}
      <section id="whyChoose" style={styles.whyChooseSection}>
        <h2 style={styles.sectionTitle}>Why Choose UpSkillX?</h2>
        <div style={styles.pointsContainer}>
          <div style={isVisible ? styles.leftColumnVisible : styles.leftColumnHidden}>
            <p>🤖 <b>AI-Powered Recommendations:</b> Get smart suggestions for courses and career paths.</p>
            <p>🔗 <b>Seamless Integration:</b> Connect with various learning resources effortlessly.</p>
            <p>🎮 <b>Gamified Experience:</b> Earn badges, climb leaderboards, and stay motivated.</p>
          </div>
          <div style={isVisible ? styles.rightColumnVisible : styles.rightColumnHidden}>
            <p>✅ <b>Personalized Learning:</b> UpSkillX evaluates your skills and adapts to your learning style.</p>
            <p>📊 <b>Real-Time Progress Tracking:</b> Monitor growth and stay on top of your learning journey.</p>
            <p>🚀 <b>Future-Ready Growth:</b> Upskill smarter, faster, and more effectively with AI-driven insights.</p>
          </div>
        </div>
      </section>
      
      {/* Image Slider */}
      <section style={styles.exploreSection}>
        <h2 style={styles.sectionTitle}>Explore Learning</h2>
        <div style={styles.carouselContainer}>
          <Slider {...sliderSettings}>
            {randomImages.map((img, index) => (
              <div key={index}>
                <img src={img} alt={`Learning ${index + 1}`} style={styles.image} />
              </div>
            ))}
          </Slider>
        </div>
      </section>
    
    {/* Contact Section */}
    <section style={styles.contactSection}>
    <h2 style={styles.sectionTitle}>Contact Us</h2>
    <p>Email: <a href="mailto:support@upskillx.com" style={styles.contactLink}>support@upskillx.com</a></p>
    <p>Phone: <a href="tel:+1234567890" style={styles.contactLink}>+1 234 567 890</a></p>
  </section>
</div>
  );
}

// Styles
const styles = {
  container: { fontFamily: "Arial, sans-serif", color: "#222", textAlign: "center", background: "#E6F7FF" },
  
  heroSection: { 
    display: "flex", 
    alignItems: "center", 
    justifyContent: "space-between", 
    padding: "50px", 
    background: "linear-gradient(135deg, #FEE140, #FA709A)",
  },
  heroTitle: { fontSize: "3.2rem", marginBottom: "10px", textShadow: "0 0 10px #FF5733" },
  heroSubtitle: { fontSize: "2.8rem", marginBottom: "20px", textShadow: "0 0 10px #FEE140" },
  heroImage: { width: "400px", height: "400px", borderRadius: "15px", boxShadow: "0 0 20px #FA709A" },
  buttonContainer: { display: "flex", gap: "15px",justifyContent: "center",  // Centers horizontally
    alignItems: "center",      // Centers vertically (if needed)
    width: "100%", },
  
  glowButton: {
    padding: "10px 25px", fontSize: "1rem", borderRadius: "8px", border: "none", cursor: "pointer",
    color: "#fff", background: "linear-gradient(135deg, #FF5733, #FFC312)",
    boxShadow: "0 0 10px #FF5733", transition: "0.3s",
  },

  // Why Choose UpSkillX Section
  whyChooseSection: { padding: "60px 20px", background: "linear-gradient(135deg, #FF5733, #FFC312)", color: "white" },
  pointsContainer: { display: "flex", justifyContent: "space-between", maxWidth: "800px", margin: "auto" },

  // Hidden styles before animation
  leftColumnHidden: {
    width: "45%", opacity: 0, transform: "translateX(-50px)", transition: "opacity 0.8s ease-out, transform 0.8s ease-out"
  },
  rightColumnHidden: {
    width: "45%", opacity: 0, transform: "translateX(50px)", transition: "opacity 0.8s ease-out, transform 0.8s ease-out"
  },

  // Visible styles after animation triggers
  leftColumnVisible: {
    width: "45%", opacity: 1, transform: "translateX(0)", transition: "opacity 0.8s ease-out, transform 0.8s ease-out"
  },
  rightColumnVisible: {
    width: "45%", opacity: 1, transform: "translateX(0)", transition: "opacity 0.8s ease-out, transform 0.8s ease-out"
  },
  
  exploreSection: { padding: "60px 20px", background: "linear-gradient(135deg, #FEE140, #FA709A)" },
  sectionTitle: { fontSize: "2rem", marginBottom: "20px", textShadow: "0 0 10px #FF5733", color: "black" },
  carouselContainer: { width: "100%", margin: "0 auto" },
  image: { width: "100%", borderRadius: "5px", boxShadow: "0 0 10px #FA709A" },
  contactSection: { padding: "40px 20px", background: "linear-gradient(135deg, #FF5733, #FFC312)", color: "#222" },
  contactLink: { color: "white", textDecoration: "none", fontWeight: "bold" }
};

export default LandingPage;
