import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import "../styles.css";

// InsightCard component for each expandable card with like and complete functionality
const InsightCard = ({ title, icon, content, color }) => {
  const [liked, setLiked] = useState(false);
  const [read, setRead] = useState(false);

  const storageKey = `insight-${title.replace(/\s+/g, "-").toLowerCase()}`;

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem(storageKey));
    if (stored) {
      setLiked(stored.liked);
      setRead(stored.read);
    }
  }, [storageKey]);

  const updateStorage = (newLiked, newRead) => {
    localStorage.setItem(storageKey, JSON.stringify({ liked: newLiked, read: newRead }));
  };

  const toggleLike = () => {
    const newLiked = !liked;
    setLiked(newLiked);
    updateStorage(newLiked, read);
  };

  const toggleRead = () => {
    const newRead = !read;
    setRead(newRead);
    updateStorage(liked, newRead);
  };

  return (
    <div
      style={{
        ...styles.card,
        borderLeft: `6px solid ${color}`,
        backgroundColor: "#fff",
      }}
    >
      <div style={styles.cardHeader}>
        <h3 style={styles.cardTitle}>
          {icon} {title}
        </h3>
        <div style={styles.cardActions}>
          <span
            role="button"
            title={liked ? "Unlike" : "Like"}
            style={{ ...styles.actionButton, color: liked ? "#e74c3c" : "#555" }}
            onClick={toggleLike}
          >
            {liked ? "❤️" : "🤍"}
          </span>
          <span
            role="button"
            title={read ? "Mark as Incomplete" : "Mark as Complete"}
            style={{ ...styles.actionButton, color: read ? "#27ae60" : "#555" }}
            onClick={toggleRead}
          >
            {read ? "✅" : "⬜"}
          </span>
        </div>
      </div>
      <div style={styles.cardContent}>
      {Array.isArray(content) ? (
  content.map((point, idx) => (
    <p key={idx} style={{ marginBottom: "10px" }}>
      🔹 {point}
    </p>
  ))
) : typeof content === "object" ? (
  Object.entries(content).map(([key, value], idx) => (
    <p key={idx} style={{ marginBottom: "10px" }}>
      <strong>{key}:</strong> {Array.isArray(value) ? value.join(", ") : value}
    </p>
  ))
) : typeof content === "string" ? (
  content
    .split(/\s(?=\d+\.)/)
    .map((point, idx) => (
      <p key={idx} style={{ marginBottom: "10px" }}>
        {point.trim()}
      </p>
    ))
) : null}


      </div>
    </div>
  );
};


// InsightsPage component to display all AI insights
const InsightsPage = () => {
  const location = useLocation();
  const { insights, loading } = location.state || {};

  useEffect(() => {
    console.log("Insights received:", insights);
  }, [insights]);

  return (
    <div className="insights-section" style={styles.container}>
      <h2 style={styles.heading}>📈 AI Performance Insights</h2>
      {loading ? (
        <p style={styles.loading}>⏳ Generating personalized insights for you...</p>
      ) : insights ? (
        <>
          {insights.deepInsights && (
            <InsightCard
              title="Deep Analysis"
              icon="🔍"
              content={insights.deepInsights}
              color="#8e44ad"
            />
          )}
          {insights.incorrectAnalysis && (
            <InsightCard
              title="Incorrect Answers"
              icon="❌"
              content={insights.incorrectAnalysis}
              color="#e74c3c"
            />
          )}
          {insights.personalizedRoadmap && (
            <InsightCard
              title="Roadmap to Improve"
              icon="🧠"
              content={insights.personalizedRoadmap}
              color="#3498db"
            />
          )}
          {insights.advancedTechniques && (
            <InsightCard
              title="Improvement Techniques"
              icon="🛠️"
              content={insights.advancedTechniques}
              color="#27ae60"
            />
          )}
          {insights.jobPrepAdvice && (
            <InsightCard
              title="Job-Readiness Tips"
              icon="🚀"
              content={insights.jobPrepAdvice}
              color="#f39c12"
            />
          )}
          {insights.motivation && (
            <InsightCard
              title="Motivational Advice"
              icon="💬"
              content={insights.motivation}
              color="#9b59b6"
            />
          )}
        </>
      ) : (
        <p style={styles.loading}>⚠️ No insights found. Please try again.</p>
      )}
    </div>
  );
};

// Inline styles
const styles = {
  container: {
    padding: "30px",
    maxWidth: "900px",
    margin: "30px auto",
    backgroundColor: "#f4f6f8",
    borderRadius: "16px",
    boxShadow: "0 6px 16px rgba(0,0,0,0.06)",
  },
  heading: {
    fontSize: "26px",
    color: "#222",
    marginBottom: "25px",
    fontWeight: "600",
    textAlign: "center",
  },
  loading: {
    fontSize: "18px",
    fontStyle: "italic",
    color: "#555",
    textAlign: "center",
  },
  card: {
    padding: "20px",
    borderRadius: "12px",
    marginBottom: "20px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
    transition: "all 0.3s ease",
    position: "relative",
  },
  cardHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  cardTitle: {
    fontSize: "20px",
    fontWeight: "600",
    color: "#333",
  },
  cardActions: {
    display: "flex",
    gap: "12px",
  },
  actionButton: {
    fontSize: "20px",
    cursor: "pointer",
    transition: "color 0.2s ease",
  },
  cardContent: {
    marginTop: "15px",
    fontSize: "16px",
    color: "#444",
    lineHeight: "1.6",
    whiteSpace: "pre-wrap",
  },
};

export default InsightsPage;
