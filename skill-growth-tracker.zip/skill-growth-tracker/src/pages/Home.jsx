// pages/Home.jsx
import React from "react";

function Home() {
  return <h1>Welcome to Skill Growth Tracker</h1>;
}

export default Home;
