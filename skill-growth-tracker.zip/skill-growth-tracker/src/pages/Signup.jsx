import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { auth } from "../Firebase";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { FaEye, FaEyeSlash } from "react-icons/fa"; // Import eye icons

function Signup() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleSignup = async (e) => {
    e.preventDefault();
    try {
      await createUserWithEmailAndPassword(auth, email, password);
      alert("Signup Successful!");
      navigate("/dashboard"); // Redirect after successful signup
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.signupBox}>
        <h2 style={styles.title}>Create an Account</h2>
        {error && <p style={styles.errorMessage}>{error}</p>}
        <form onSubmit={handleSignup} style={styles.form}>
          <input
            type="email"
            placeholder="Email"
            onChange={(e) => setEmail(e.target.value)}
            required
            style={styles.input}
          />
          <div style={styles.passwordContainer}>
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Password"
              onChange={(e) => setPassword(e.target.value)}
              required
              style={styles.passwordInput}
            />
            <span
              onClick={() => setShowPassword(!showPassword)}
              style={styles.eyeIcon}
            >
              {showPassword ? <FaEyeSlash /> : <FaEye />}
            </span>
          </div>
          <button type="submit" style={styles.button}>Sign Up</button>
        </form>
        <p style={styles.loginText}>
          Already have an account?{" "}
          <span onClick={() => navigate("/login")} style={styles.loginLink}>
            Log in
          </span>
        </p>
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100vh",
    background: "linear-gradient(135deg, #FEE140, #FA709A)",
  },
  signupBox: {
    background: "rgba(255, 255, 255, 0.1)",
    backdropFilter: "blur(15px)",
    padding: "2.5rem",
    borderRadius: "15px",
    textAlign: "center",
    boxShadow: "0 0 20px rgba(255, 165, 0, 0.5)",
    animation: "fadeIn 1s ease-in-out",
    width: "350px",
    transition: "all 0.3s ease-in-out",
  },
  title: {
    fontSize: "2rem",
    color: "black",
    textShadow: "0 0 10px rgba(255, 165, 0, 0.8)",
    marginBottom: "15px",
  },
  errorMessage: {
    color: "red",
    fontSize: "0.9rem",
    marginBottom: "10px",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "20px",
  },
  input: {
    width: "90%",
    padding: "12px",
    background: "rgba(255, 255, 255, 0.93)",
    border: "1px solid rgba(242, 237, 237, 0.72)",
    color: "black",
    borderRadius: "8px",
    outline: "none",
    fontSize: "1rem",
    transition: "all 0.3s ease-in-out",
  },
  passwordContainer: {
    position: "relative",
    width: "90%",
  },
  passwordInput: {
    width: "100%",
    padding: "12px",
    background: "rgba(255, 255, 255, 0.93)",
    border: "1px solid rgba(242, 237, 237, 0.72)",
    color: "black",
    borderRadius: "8px",
    outline: "none",
    fontSize: "1rem",
    transition: "all 0.3s ease-in-out",
  },
  eyeIcon: {
    position: "absolute",
    right: "10px",
    top: "50%",
    transform: "translateY(-50%)",
    cursor: "pointer",
    color: "#FF5733",
    fontSize: "1.2rem",
  },
  button: {
    background: "linear-gradient(90deg, #FF5733, #FFC312)",
    border: "none",
    padding: "12px",
    color: "white",
    fontSize: "1rem",
    borderRadius: "8px",
    cursor: "pointer",
    transition: "all 0.3s ease-in-out",
    boxShadow: "0 0 15px rgba(255, 165, 0, 0.7)",
    width: "98%",
  },
  loginText: {
    marginTop: "15px",
    color: "black",
  },
  loginLink: {
    color: "black",
    fontWeight: "bold",
    cursor: "pointer",
    textDecoration: "underline",
  },
};

export default Signup;
