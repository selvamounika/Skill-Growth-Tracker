import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { PieChart, Pie, Cell, Tooltip, Legend } from "recharts";
import { firestore } from "../Firebase.jsx";
import { doc, setDoc } from "firebase/firestore";
import { serverTimestamp } from "firebase/firestore";

import "../rstyles.css";

const Results = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { domain,questions = [], userAnswers = {}, userId } = location.state || {};
  const [loading, setLoading] = useState(false);
  const [insights, setInsights] = useState(null);

  if (!questions.length) {
    return (
      <div className="result-box">
        <h2 className="test-title">No Results Found</h2>
        <p>Please complete a test to view results.</p>
      </div>
    );
  }

  const calculateScore = () => {
    return questions.reduce((acc, q) => {
      return userAnswers[q.id] === q.correctAnswer ? acc + 1 : acc;
    }, 0);
  };

  const score = calculateScore();
  const total = questions.length;

  const pieData = [
    { name: "Correct", value: score },
    { name: "Incorrect", value: total - score },
  ];
  const COLORS = ["#28a745", "#dc3545"];

  const fetchInsights = async () => {
    setLoading(true);
  
    if ((!score && score !== 0) || !total || !Array.isArray(questions) || questions.length === 0) {
      console.error("❌ Invalid test data. Score, total, or questions are missing.");
      setLoading(false);
      return;
    }
  
    const cleanedQuestions = questions.map((q) => ({
      id: q.id,
      question: q.question,
      correctAnswer: q.correctAnswer,
      userAnswer: userAnswers[q.id],
      topic: q.topic || "Unknown",
    }));
  
    const payload = {
      score,
      total,
      questions: cleanedQuestions,
      userAnswers,
    };
  
    console.log("📤 Sending to AI Insights API:", payload);
  
    try {
      const response = await fetch("/api/generate-insights", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
  
      if (!response.ok) {
        const errMessage = await response.text();
        throw new Error(`Failed to fetch insights: ${errMessage}`);
      }
  
      const rawData = await response.text();
      let parsedData;
  
      try {
        parsedData = JSON.parse(rawData);
      } catch (jsonError) {
        console.error("❌ JSON parsing failed. Possibly due to truncated response:", rawData);
        throw new Error("Invalid AI response. The content may be incomplete or too long.");
      }
  
      const generatedInsights = parsedData.insights;
      if (!generatedInsights) throw new Error("Insights data missing from AI response.");
  
      setInsights(generatedInsights);
      await storeTestDataInFirestore(generatedInsights);
  
      navigate("/insights", {
        state: {
          insights: generatedInsights,
          testMeta: { score, total },
        },
      });
    } catch (error) {
      console.error("❌ Error fetching AI-generated insights:", error.message);
      alert("Sorry, we couldn’t generate insights this time. Please try again.");
      setInsights(null);
    }
  
    setLoading(false);
  };
  

  const storeTestDataInFirestore = async (insights) => {
    if (!userId) {
      console.error("userId is missing. Cannot store test data.");
      return;
    }
  
    try {
      const testId = crypto.randomUUID(); // generate a unique ID
      const testRef = doc(firestore, `users/${userId}/tests/${testId}`);
  
      await setDoc(testRef, {
        score,
        questions,
        totalQuestions: questions.length,
        userAnswers,
        insights,
        domain: domain || "Unknown",
        topic: questions[0]?.topic || "Unknown",
        testId,
        timestamp: serverTimestamp(),
      });
  
      console.log("Test results stored successfully with ID:", testId);
    } catch (error) {
      console.error("Error storing test data in Firestore:", error);
    }
  };

  return (
    <div className="result-box">
      <h2 className="test-title">Test Results</h2>
      <p className="score-text-enhanced">
  <span className="score-value">{score}</span>
  <span className="score-divider">/</span>
  <span className="score-total">{total}</span>
</p>


      <div className="chart-container">
        <PieChart width={300} height={300}>
          <Pie
            data={pieData}
            cx="50%"
            cy="50%"
            outerRadius={100}
            fill="#8884d8"
            dataKey="value"
            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
          >
            {pieData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index]} />
            ))}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </div>

      <div className="show-insights-button" style={{ marginTop: "20px", textAlign: "center" }}>
        <button
          onClick={fetchInsights}
          disabled={loading}
          style={{
            padding: "10px 20px",
            backgroundColor: "#007bff",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            cursor: loading ? "not-allowed" : "pointer",
            fontSize: "16px",
            marginBottom: "20px",
          }}
        >
          {loading ? "Generating Insights..." : "Show AI Insights"}
        </button>
      </div>

      {questions.map((q, index) => {
        const userAnswer = userAnswers[q.id];
        return (
          <div key={q.id} className="question-box">
            <p className="question-text">{index + 1}. {q.question}</p>
            <div className="options-list">
              {q.options.map((option) => {
                const isCorrect = q.correctAnswer === option;
                const isUserAnswer = userAnswer === option;

                let optionClass = "option-label";
                if (isCorrect) optionClass += " correct";
                else if (isUserAnswer) optionClass += " incorrect";

                return (
                  <div key={option} className={optionClass}>
                    <span>{option}</span>
                    {isCorrect && <span> ✅</span>}
                    {isUserAnswer && !isCorrect && <span> ❌</span>}
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default Results;
