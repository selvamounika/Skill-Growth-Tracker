import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import Navbar from "../components/Navbar";
import { getTestDetails } from "../Firestore";
import "../styles.css";

function TestDetailsPage() {
  const { testId } = useParams();
  const [testData, setTestData] = useState(null);

  useEffect(() => {
    const fetchTestData = async () => {
      const data = await getTestDetails(testId);
      console.log("Test Data Fetched: ", data);
      setTestData(data);
    };

    fetchTestData();
  }, [testId]);

  if (!testData) return <p>Loading test details...</p>;

  const {
    domain,
    topic,
    score,
    totalQuestions,
    insights,
    questions = [],
    userAnswers = {},
  } = testData;

  const renderRoadmap = (roadmap) => {
    if (roadmap && typeof roadmap === "object") {
      return (
        <ul>
          {Object.entries(roadmap).map(([week, task]) => (
            <li key={week}>
              <strong>{week}:</strong> {task}
            </li>
          ))}
        </ul>
      );
    } else {
      return <p>No roadmap available.</p>;
    }
  };

  const renderAdvancedTechniques = (techniques) => {
    if (techniques && typeof techniques === "object") {
      return (
        <ul>
          {Object.entries(techniques).map(([key, value]) => (
            <li key={key}>
              <strong>{key}:</strong> {value}
            </li>
          ))}
        </ul>
      );
    } else {
      return <p>No advanced techniques available.</p>;
    }
  };

  return (
    <div className="test-container">
      <Navbar />
      <div className="test-content">
        <h1 className="test-title">📊 Test Details</h1>

        <div className="result-box">
          <p><strong>🧭 Domain:</strong> {domain}</p>
          <p><strong>📌 Topic:</strong> {topic}</p>
          <p><strong>🎯 Score:</strong> {score} / {totalQuestions}</p>
        </div>

        <h3 className="test-section">📘 AI Insights</h3>
        {insights ? (
          <div className="insight-section">
            <p><strong>Deep Insights:</strong> {insights.deepInsights}</p>

            <p><strong>Personalized Roadmap:</strong></p>
            {renderRoadmap(insights.personalizedRoadmap)}

            <p><strong>Advanced Techniques:</strong></p>
            {renderAdvancedTechniques(insights.advancedTechniques)}

            <p><strong>💼 Job Prep Advice:</strong></p>
<ul>
  <li>
    <strong>Interview Practice:</strong>{" "}
    {insights.jobPrepAdvice?.interviewPractice ||
      insights.jobPrepAdvice?.["Interview Practice"] ||
      "Not available"}
  </li>
  <li>
    <strong>Portfolio Tips:</strong>{" "}
    {insights.jobPrepAdvice?.portfolioTips ||
      insights.jobPrepAdvice?.["Portfolio Tips"] ||
      "Not available"}
  </li>
  <li>
    <strong>Skill Checkpoints:</strong>{" "}
    {insights.jobPrepAdvice?.skillCheckpoints ||
      insights.jobPrepAdvice?.["Skill Checkpoints"] ||
      "Not available"}
  </li>
</ul>



            <p><strong>Motivation:</strong> {insights.motivation}</p>
          </div>
        ) : (
          <p>No insights available for this test.</p>
        )}

        {insights?.incorrectAnalysis && (
          <div className="insight-section">
            <h4>❌ Misconceptions Identified</h4>
            {Object.entries(insights.incorrectAnalysis).map(([topic, feedback], index) => (
              <p key={index}><strong>{topic}:</strong> {feedback}</p>
            ))}
          </div>
        )}

        <h3 className="test-section">📝 Questions & Answers</h3>
        {questions.length > 0 ? (
          <div className="questions-list">
            {questions.map((q, index) => (
              <div key={q.id} className="question-box">
                <p><strong>Q{index + 1}:</strong> {q.question}</p>
                <p><strong>Your Answer:</strong> {userAnswers[q.id]}</p>
                <p><strong>Correct Answer:</strong> {q.correctAnswer}</p>
                <p
                  style={{
                    color: userAnswers[q.id] === q.correctAnswer ? "green" : "red",
                    fontWeight: "bold"
                  }}
                >
                  {userAnswers[q.id] === q.correctAnswer ? "Correct ✅" : "Incorrect ❌"}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <p>No question data available.</p>
        )}
      </div>
    </div>
  );
}

export default TestDetailsPage;
