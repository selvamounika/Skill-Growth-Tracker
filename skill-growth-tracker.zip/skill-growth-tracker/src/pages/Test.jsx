import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles.css";
import Navbar from "../components/Navbar";
import axios from "axios";
import { v4 as uuidv4 } from "uuid"; // For unique test ID
import { getAuth } from "firebase/auth";

function Test() {
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedTopic, setSelectedTopic] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [userAnswers, setUserAnswers] = useState({});
  const [loading, setLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const navigate = useNavigate();

  const getTopicsByCategory = (category) => {
    const topics = {
      "Software-Based": [
        "Web Development", "AI/ML", "Cybersecurity", "Mobile App Development",
        "UI/UX Design", "Cloud Computing", "Data Science", "Blockchain Development",
        "Game Development", "DevOps", "Software Architecture", "Software Testing",
        "Full-Stack Development", "Database Management", "Artificial Intelligence in Healthcare"
      ],
      "Hardware-Based": [
        "Embedded Systems", "VLSI Design", "IoT", "Robotics", "Networking",
        "Artificial Intelligence in Hardware", "Digital Circuit Design", "Communication Systems",
        "Computer Networks", "Semiconductor Devices", "Power Systems", "Signal Processing",
        "Embedded Software Development", "Automation and Control Systems", "Computer Vision"
      ],
      "Business & Management": [
        "Marketing", "Finance", "Operations", "Human Resources", "Project Management",
        "Business Analytics", "Digital Transformation", "Supply Chain Management", "Entrepreneurship",
        "Leadership and Strategy", "Risk Management", "Customer Relationship Management (CRM)",
        "Data-driven Decision Making", "Agile Project Management", "International Business"
      ]
    };
    return topics[category] || [];
  };

  const fetchAIQuestions = async (category, topic) => {
    setLoading(true);
    try {
      const response = await axios.post("/api/generate-questions", {
        category,
        topic,
      });

      if (response.data && response.data.questions) {
        setQuestions(response.data.questions);
      } else {
        setQuestions([]);
      }
    } catch (error) {
      console.error("Error fetching AI-generated questions:", error);
      setQuestions([]);
    } finally {
      setLoading(false);
    }
  };

  const handleCategorySelection = (category) => {
    setSelectedCategory(category);
    setSelectedTopic(null);
    setQuestions([]);
  };

  const handleTopicSelection = (topic) => {
    setSelectedTopic(topic);
    fetchAIQuestions(selectedCategory, topic);
  };

  const handleAnswer = (questionId, answer) => {
    setUserAnswers({ ...userAnswers, [questionId]: answer });
  };

  const calculateScore = () => {
    let score = 0;
    questions.forEach((q) => {
      if (userAnswers[q.id] === q.correctAnswer) {
        score += 1;
      }
    });
    return score;
  };

  const submitTest = () => {
    setIsSubmitted(true);
    const score = calculateScore();
    const testId = uuidv4();

    const auth = getAuth();
    const user = auth.currentUser;

    if (!user) {
      alert("User not logged in. Please log in again.");
      navigate("/login");
      return;
    }

    const userId = user.uid;

    // Navigate to the results page with all required data
    navigate("/results", {
      state: {
        questions,
        userAnswers,
        score,
        userId,
        domain: selectedCategory,
        topic: selectedTopic,
        testId,
        timestamp: new Date().toISOString(),
      },
    });
  };

  return (
    <div className="test-container">
      <Navbar />
      <div className="test-content">
        <h1 className="test-title">Welcome to UpSkillX !!</h1>

        {!selectedCategory ? (
          <div className="category-selection">
            <h2>Select a Category</h2>
            <button className="btn hardware" onClick={() => handleCategorySelection("Hardware-Based")}>
              Hardware-Based
            </button>
            <button className="btn software" onClick={() => handleCategorySelection("Software-Based")}>
              Software-Based
            </button>
            <button className="btn business" onClick={() => handleCategorySelection("Business & Management")}>
              Business & Management
            </button>
          </div>
        ) : !selectedTopic ? (
          <div className="topic-selection">
            <h2>Select a Topic under {selectedCategory}</h2>
            {getTopicsByCategory(selectedCategory).map((topic) => (
              <button key={topic} className="btn topic" onClick={() => handleTopicSelection(topic)}>
                {topic}
              </button>
            ))}
          </div>
        ) : loading ? (
          <p className="loading-text">Generating Questions...</p>
        ) : (
          <div className="test-section">
            <h2 className="test-title">
              Test: {selectedTopic} ({selectedCategory})
            </h2>
            {questions.length === 0 ? (
              <p>No questions available for the selected topic.</p>
            ) : (
              questions.map((q, index) => (
                <div key={q.id} className="question-box">
                  <p className="question-text">{index + 1}. {q.question}</p>
                  <div className="options-list">
                    {q.options.map((option) => (
                      <label
                        key={option}
                        className={`option-label ${
                          isSubmitted && userAnswers[q.id] === option
                            ? option === q.correctAnswer
                              ? "correct"
                              : "incorrect"
                            : ""
                        }`}
                      >
                        <input
                          type="radio"
                          name={`question-${q.id}`}
                          value={option}
                          checked={userAnswers[q.id] === option}
                          onChange={() => handleAnswer(q.id, option)}
                        />
                        <span>{option}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ))
            )}
            <button className="btn submit" onClick={submitTest}>
              Submit Test
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default Test;
