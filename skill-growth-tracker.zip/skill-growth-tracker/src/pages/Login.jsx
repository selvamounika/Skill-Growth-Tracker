import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { auth } from "../Firebase";
import { signInWithEmailAndPassword } from "firebase/auth";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      await signInWithEmailAndPassword(auth, email, password);
      alert("Login Successful!");
      navigate("/dashboard"); // Redirect to dashboard after login
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.loginBox}>
        <h2 style={styles.title}>Welcome Back!</h2>
        {error && <p style={styles.errorMessage}>{error}</p>}
        <form onSubmit={handleLogin} style={styles.form}>
          <input
            type="email"
            placeholder="Email"
            onChange={(e) => setEmail(e.target.value)}
            required
            style={styles.input}
          />
          <input
            type="password"
            placeholder="Password"
            onChange={(e) => setPassword(e.target.value)}
            required
            style={styles.input}
          />
          <button type="submit" style={styles.button}>Login</button>
        </form>
        <p style={styles.signupText}>
          Don't have an account?{" "}
          <span onClick={() => navigate("/signup")} style={styles.signupLink}>
            Sign Up
          </span>
        </p>
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100vh",
    background: "linear-gradient(135deg, #FEE140, #FA709A)",
  },
  loginBox: {
    background: "rgba(255, 255, 255, 0.1)",
    backdropFilter: "blur(15px)",
    padding: "2.5rem",
    borderRadius: "15px",
    textAlign: "center",
    boxShadow: "0 0 20px rgba(255, 165, 0, 0.5)",
    animation: "fadeIn 1s ease-in-out",
    width: "350px",
    transition: "all 0.3s ease-in-out",
  },
  title: {
    fontSize: "2rem",
    color: "black",
    textShadow: "0 0 10px rgba(255, 165, 0, 0.8)",
    marginBottom: "15px",
  },
  errorMessage: {
    color: "red",
    fontSize: "0.9rem",
    marginBottom: "10px",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "20px",
  },
  input: {
    width: "90%",
    padding: "12px",
    background: "rgba(255, 255, 255, 0.93)",
    border: "1px solid rgba(242, 237, 237, 0.72)",
    color: "black",
    borderRadius: "8px",
    outline: "none",
    fontSize: "1rem",
    transition: "all 0.3s ease-in-out",
  },
  button: {
    background: "linear-gradient(90deg, #FF5733, #FFC312)",
    border: "none",
    padding: "12px",
    color: "white",
    fontSize: "1rem",
    borderRadius: "8px",
    cursor: "pointer",
    transition: "all 0.3s ease-in-out",
    boxShadow: "0 0 15px rgba(255, 165, 0, 0.7)",
    width: "98%",
  },
  buttonHover: {
    transform: "scale(1.05)",
    boxShadow: "0 0 25px rgba(255, 165, 0, 0.9)",
  },
  inputFocus: {
    border: "1px solid #FF5733",
    boxShadow: "0 0 10px rgba(255, 87, 51, 0.8)",
  },
  signupText: {
    marginTop: "15px",
    color: "black",
  },
  signupLink: {
    color: "black",
    fontWeight: "bold",
    cursor: "pointer",
    textDecoration: "underline",
  },
};

export default Login;
