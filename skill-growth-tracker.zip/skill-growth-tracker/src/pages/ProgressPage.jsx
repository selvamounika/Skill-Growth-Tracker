import React, { useState, useEffect } from "react";
import { getUserTests } from "../Firestore.jsx";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from "recharts";

function Progress() {
  const [tests, setTests] = useState([]);
  const [weeklyStats, setWeeklyStats] = useState([]);
  const [streak, setStreak] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchTests = async () => {
      const fetchedTests = await getUserTests();
      // Filter only tests with insights
      const testsWithInsights = fetchedTests.filter(test => test.insights && Object.keys(test.insights).length > 0);
      setTests(testsWithInsights);
      processStats(testsWithInsights);
    };

    fetchTests();
  }, []);

  const handleTestClick = (testId) => {
    navigate(`/testdetails/${testId}`);
  };

  const processStats = (tests) => {
    const now = new Date();
    const dateMap = {};
    const dateSet = new Set();

    // Get dates for last 7 days
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(now.getDate() - i);
      const key = date.toDateString();
      dateMap[key] = 0;
    }

    tests.forEach((test) => {
      if (test.timestamp && test.timestamp.toDate) {
        const date = test.timestamp.toDate().toDateString();
        if (dateMap[date] !== undefined) {
          dateMap[date] ++;
        }
        dateSet.add(date);
      }
    });

    // Weekly growth chart data
    const chartData = Object.keys(dateMap).map((date) => ({
      date: date.split(" ").slice(1, 3).join(" "), // e.g. "Apr 18"
      tests: dateMap[date],
    }));
    setWeeklyStats(chartData);

    // Calculate streak
    let streakCount = 0;
    let today = new Date();

    while (dateSet.has(today.toDateString())) {
      streakCount++;
      today.setDate(today.getDate() - 1);
    }
    setStreak(streakCount);
  };

  return (
    <div className="progress-container">
      <Navbar />
      <div className="progress-content">
        <h1 className="progress-heading">Your Test Progress</h1>

        {/* 📈 Weekly Stats */}
        <div className="stats-section">
          <h2>📈 Weekly Growth</h2>
          {weeklyStats.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={weeklyStats}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Line type="monotone" dataKey="tests" stroke="#8884d8" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <p>No data for the past 7 days.</p>
          )}
        </div>

        {/* 🔥 Streak Tracker */}
        <div className="streak-section">
          <h2>🔥 Current Streak</h2>
          <p>You’ve been active for <strong>{streak}</strong> {streak === 1 ? "day" : "days"} in a row!</p>
        </div>

        {/* 🧠 Test Cards */}
        {tests.length > 0 ? (
          <div className="test-cards-grid">
            {tests.map((test) => (
              <div key={test.testId} className="test-card">
                <h2 className="test-title">{test.domain}</h2>
                <p className="test-topic"><strong>Topic:</strong> {test.topic}</p>
                <p className="test-score"><strong>Score:</strong> {test.score}</p>
                <div className="button-row">
                  <button className="view-details-btn" onClick={() => handleTestClick(test.testId)}>
                    View Details
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="no-tests-msg">No tests with insights available.</p>
        )}
      </div>
    </div>
  );
}

export default Progress;
