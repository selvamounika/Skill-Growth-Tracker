import React from "react";
import { useNavigate } from "react-router-dom";

const Navbar = () => {
  const navigate = useNavigate();

  return (
    <nav style={styles.navbar}>
      <h1 style={styles.logo} onClick={() => navigate("/")}>UpSkillX 🚀 </h1>

      {/* Profile Button */}
      <button style={styles.profileButton} onClick={() => navigate("/profile")}>
        Profile
      </button>
    </nav>
  );
};

// Styles
const styles = {
  navbar: {
    
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "15px 30px",
    background: "linear-gradient(135deg, #FF5733, #FFC312)",
    color: "#fff",
    fontSize: "1.2rem",
    fontWeight: "bold",
  },
  logo: {
    cursor: "pointer",
    fontSize: "1.5rem",
    textShadow: "0 0 5px rgba(255,255,255,0.8)",
  },
  profileButton: {
    background: "#fff",
    color: "#FF5733",
    border: "none",
    padding: "8px 15px",
    fontSize: "1rem",
    fontWeight: "bold",
    borderRadius: "5px",
    cursor: "pointer",
    transition: "0.3s",
    boxShadow: "0px 3px 6px rgba(0,0,0,0.2)",
  },
};

export default Navbar;
