import React, { useState } from "react";

const ProfileSection = ({ user, onSave }) => {
  const [profile, setProfile] = useState({
    name: user?.name || "",
    email: user?.email || "",
    dob: user?.dob || "",
    location: user?.location || "",
    experience: user?.experience || "",
    bio: user?.bio || "",
    interests: user?.interests || [],
    otherInterest: "",
  });

  const allDomains = [
    "Web Development", "Data Science", "AI/ML", "Cybersecurity",
    "Cloud Computing", "UI/UX Design", "DevOps", "Blockchain",
    "Game Development", "Mobile App Development"
  ];

  const handleChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  const handleInterestChange = (domain) => {
    const updatedInterests = profile.interests.includes(domain)
      ? profile.interests.filter((d) => d !== domain)
      : [...profile.interests, domain];

    setProfile({ ...profile, interests: updatedInterests });
  };

  const handleSave = () => {
    onSave(profile);
    alert("Profile Updated!");
  };

  return (
    <div style={styles.pageBackground}>
      <div style={styles.container}>
        <h2 style={styles.title}>Edit Profile</h2>

        {["name", "email", "dob", "location"].map((field) => (
          <div key={field}>
            <label style={styles.label}>{field.charAt(0).toUpperCase() + field.slice(1)}:</label>
            <input
              type={field === "email" ? "email" : field === "dob" ? "date" : "text"}
              name={field}
              value={profile[field]}
              onChange={handleChange}
              placeholder={`Enter ${field}`}
              style={{
                ...styles.input,
                background: profile[field] ? "linear-gradient(135deg, #FF5733, #FFC312)" : "#fff",
                color: profile[field] ? "white" : "black"
              }}
            />
          </div>
        ))}

        <label style={styles.label}>Experience Level:</label>
        <select
          name="experience"
          value={profile.experience}
          onChange={handleChange}
          style={{
            ...styles.input,
            background: profile.experience ? "linear-gradient(135deg, #FF5733, #FFC312)" : "#fff",
            color: profile.experience ? "white" : "black"
          }}
        >
          <option value="">Select</option>
          <option value="Beginner">Beginner</option>
          <option value="Intermediate">Intermediate</option>
          <option value="Advanced">Advanced</option>
        </select>

        <label style={styles.label}>Short Bio:</label>
        <textarea
          name="bio"
          value={profile.bio}
          onChange={handleChange}
          placeholder="Write a short bio..."
          style={{
            ...styles.textarea,
            background: profile.bio ? "linear-gradient(135deg, #FF5733, #FFC312)" : "#fff",
            color: profile.bio ? "white" : "black"
          }}
        />

        <label style={styles.label}>Domains of Interest:</label>
        <div style={styles.interestContainer}>
          {allDomains.map((domain) => (
            <label key={domain} style={styles.checkboxLabel}>
              <input
                type="checkbox"
                checked={profile.interests.includes(domain)}
                onChange={() => handleInterestChange(domain)}
              />
              {domain}
            </label>
          ))}
        </div>

        <label style={styles.label}>Other Interests:</label>
        <input
          type="text"
          name="otherInterest"
          value={profile.otherInterest}
          onChange={handleChange}
          placeholder="Enter other interest"
          style={{
            ...styles.input,
            background: profile.otherInterest ? "linear-gradient(135deg, #FF5733, #FFC312)" : "#fff",
            color: profile.otherInterest ? "white" : "black"
          }}
        />

        <button onClick={handleSave} style={styles.saveButton}>Save Profile</button>
      </div>
    </div>
  );
};

// Styles
const styles = {
  pageBackground: {
    minHeight: "100vh",
    background: "linear-gradient(135deg, #FF5733, #FFC312)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "20px",
  },
  container: {
    maxWidth: "700px",
    width: "100%",
    padding: "20px",
    background: "white",
    borderRadius: "10px",
    boxShadow: "0px 4px 10px rgba(0,0,0,0.2)",
    color: "#222",
    fontFamily: "Arial, sans-serif",
  },
  title: { textAlign: "center", fontSize: "24px", fontWeight: "bold", marginBottom: "10px" },
  label: { fontSize: "16px", fontWeight: "bold", display: "block", marginTop: "10px" },
  input: {
    width: "100%",
    padding: "8px",
    marginTop: "5px",
    borderRadius: "5px",
    border: "1px solid #ccc",
    fontSize: "14px",
    transition: "background 0.3s, color 0.3s",
  },
  textarea: {
    width: "100%",
    padding: "8px",
    marginTop: "5px",
    borderRadius: "5px",
    border: "1px solid #ccc",
    fontSize: "14px",
    height: "80px",
    resize: "none",
    transition: "background 0.3s, color 0.3s",
  },
  interestContainer: { display: "flex", flexWrap: "wrap", gap: "10px", marginTop: "5px" },
  checkboxLabel: { display: "flex", alignItems: "center", gap: "5px" },
  saveButton: {
    width: "100%",
    padding: "10px",
    marginTop: "15px",
    borderRadius: "5px",
    border: "none",
    cursor: "pointer",
    background: "linear-gradient(135deg, #FF5733, #FFC312)",
    color: "#fff",
    fontSize: "16px",
    fontWeight: "bold",
    boxShadow: "0px 3px 6px rgba(0,0,0,0.2)",
    transition: "0.3s",
  },
};

export default ProfileSection;
