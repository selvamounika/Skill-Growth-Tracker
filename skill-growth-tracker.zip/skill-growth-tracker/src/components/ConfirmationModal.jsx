import React from "react";
import "../rstyles.css"; // Add styles for modal here

const ConfirmationModal = ({ isVisible, onClose, onConfirm }) => {
  if (!isVisible) return null;

  return (
    <div className="confirmation-modal-overlay">
      <div className="confirmation-modal">
        <h3>Are you sure you want to delete this test?</h3>
        <div className="modal-buttons">
          <button className="modal-confirm-btn" onClick={onConfirm}>
            Yes, Delete
          </button>
          <button className="modal-cancel-btn" onClick={onClose}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationModal;
