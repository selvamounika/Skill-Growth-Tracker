import React from "react";

const LearningRecommendations = ({ recommendations }) => {
  return (
    <div className="p-4 bg-white shadow-md rounded-lg">
      <h2 className="text-lg font-bold mb-2">Learning Recommendations</h2>
      <ul className="list-disc pl-5">
        {recommendations.map((rec, index) => (
          <li key={index}>
            <a href={rec.link} className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">
              {rec.title}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default LearningRecommendations;
