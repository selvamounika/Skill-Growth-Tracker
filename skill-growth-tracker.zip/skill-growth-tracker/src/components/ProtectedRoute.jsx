import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth();

  // Show a loading state while authentication is being checked
  if (loading) {
    return <div>Loading...</div>;
  }

  // If user exists, allow access; otherwise, redirect to login
  return user ? children : <Navigate to="/login" replace />;
};

export default ProtectedRoute;
