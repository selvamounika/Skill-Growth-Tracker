import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore"; // Import Firestore

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDC5lMkQiEuqEx4DO5Bv2DNtYIZDdGVx-c",
  authDomain: "skill-growth-tracker.firebaseapp.com",
  projectId: "skill-growth-tracker",
  storageBucket: "skill-growth-tracker.firebasestorage.app",
  messagingSenderId: "639327333229",
  appId: "1:639327333229:web:360972fdb0d6abc09c4864"
};
// Initialize Firebase app
const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and Firestore
export const auth = getAuth(app);
export const firestore = getFirestore(app); // Export Firestore
