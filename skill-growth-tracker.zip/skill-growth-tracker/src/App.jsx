import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Signup from "./pages/Signup";
import Login from "./pages/Login";
import ProtectedRoute from "./components/ProtectedRoute";
import LandingPage from "./pages/LandingPage";
import ProfilePage from "./components/ProfileSection"; // Import ProfilePage
import InsightsPage from "./pages/Insights";
import Progress from "./pages/ProgressPage";
import Test from "./pages/Test"; // Import the TestPage (for /tests route)
import Results from "./pages/Results"; // Import the ResultsPage (for /results route)
import TestDetailsPage from "./pages/TestDetailsPage";
function App() {
  return (
    <Router>
      <Routes>
        {/* Landing Page */}
        <Route path="/" element={<LandingPage />} />

        {/* Authentication Routes */}
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />

        {/* Protected Routes (Only accessible if logged in) */}
        <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
        <Route path="/progress" element={<ProtectedRoute><Progress /></ProtectedRoute>} />

        {/* Test Flow Routes */}
        <Route path="/tests" element={<ProtectedRoute><Test /></ProtectedRoute>} /> {/* Test page route */}
        <Route path="/results" element={<ProtectedRoute><Results /></ProtectedRoute>} /> {/* Results page route */}
        <Route path="/insights" element={<ProtectedRoute><InsightsPage /></ProtectedRoute>} /> {/* Insights page route */}

        {/* Test Details Route */}
        <Route path="/testdetails/:testId" element={<ProtectedRoute><TestDetailsPage /></ProtectedRoute>} />
      </Routes>
    </Router>
  );
}

export default App;
