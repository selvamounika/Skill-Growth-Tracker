import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import axios from "axios";

dotenv.config();
const app = express();
app.use(express.json());
app.use(cors());

app.get("/", (req, res) => {
  res.send("AI Recommendation API is running...");
});

// 📌 Generate Questions Endpoint
app.post("/generate-questions", async (req, res) => {
  const { category, topic } = req.body;

  if (!category) {
    return res.status(400).json({ error: "Category is required" });
  }

  const prompt = `
Generate 20 multiple-choice questions for the ${category} domain ${topic ? `focused on the topic "${topic}"` : "covering a mix of all major topics in this domain"}.

- The first 10 questions should be **standard MCQs**.
- The next 10 questiona should be **case-based questions** that describe a scenario and ask the user to select the most appropriate option.
- All questions must have exactly 4 options and one correct answer.

Format the response as a valid JSON array like this:

[
  {
    "id": 1,
    "question": "What is React?",
    "type": "mcq",
    "options": [
      "A library",
      "A framework",
      "A language",
      "A database"
    ],
    "correctAnswer": "A library",
    "topic": "${topic}"
  },
  {
    "id": 6,
    "question": "A startup is planning to build a scalable web app. They are considering using microservices architecture. Which of the following is the most relevant reason to choose microservices?",
    "type": "case-study",
    "options": [
      "It simplifies deployment by using a monolith.",
      "It reduces network latency due to fewer services.",
      "It allows independent scaling of components.",
      "It removes the need for DevOps practices."
    ],
    "correctAnswer": "It allows independent scaling of components",
    "topic": "${topic}"
  },
  ...
]

Instructions:
- Return **only** the valid JSON array (no explanations or extra text).
- Ensure there are **no syntax errors** (e.g., no trailing commas or unterminated strings).
- Keep the language clear and concise.
`.trim();


  try {
    const response = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "openai/gpt-3.5-turbo",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.7,
        max_tokens: 1500,
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
        },
      }
    );

    console.log("✅ AI API response:", JSON.stringify(response.data, null, 2));

    if (!response.data || !Array.isArray(response.data.choices) || response.data.choices.length === 0) {
      throw new Error("No choices returned from the AI model.");
    }

    let aiResponse = response.data.choices[0]?.message?.content || "[]";
    aiResponse = aiResponse.replace(/```json|```/g, "").trim();

    const match = aiResponse.match(/\[\s*{[\s\S]*}\s*\]/);
    if (!match) {
      throw new Error("Could not find a valid JSON array in the response.");
    }

    const cleanJson = match[0];
    let parsed;
    try {
      parsed = JSON.parse(cleanJson);
    } catch (parseError) {
      console.error("❌ JSON parsing failed:", parseError.message);
      return res.status(500).json({ error: "Malformed JSON from AI. Try again." });
    }

    if (!Array.isArray(parsed)) {
      throw new Error("AI response is not an array.");
    }

    res.json({ questions: parsed });
  } catch (error) {
    console.error("❌ Error generating questions:", error.message || error.response?.data || error.stack);
    res.status(500).json({ error: "Failed to generate questions" });
  }
});

// 🧠 AI Insights Endpoint
app.post("/generate-insights", async (req, res) => {
  const { score, total, questions, userAnswers,domain } = req.body;

  if (score === undefined || total === undefined) {
    return res.status(400).json({ error: "Score and total are required" });
  }

  const prompt = `
You are an AI mentor analyzing a highly ambitious student's test performance who aims to become job-ready fast.

Based on this data:
- Score: ${score}/${total}
- Domain: ${domain}
- Answers and explanations: ${JSON.stringify({ questions, userAnswers }, null, 2)}

Respond in **JSON format only**. Include the following keys:

- "deepInsights": Analyze your performance deeply. What patterns or trends do you notice? What are the conceptual weaknesses based on wrong answers?
- "incorrectAnalysis": Group the incorrect answers by topic and explain why you likely got them wrong — was it a misunderstanding, lack of knowledge, or overconfidence?
- "personalizedRoadmap": Give a week-by-week or step-by-step roadmap to master the weak topics, using hands-on tasks or projects.
- "advancedTechniques": List focused learning techniques (books, tutorials, mini-projects, tools) that go beyond basic suggestions.
- "jobPrepAdvice": Give job-readiness advice for this domain — including portfolio tips, interview practice, and skill checkpoints.
- "motivation": End with a short, human-like motivational message that matches your current progress level.

Instructions:
- Do not include any extra text — only output a valid JSON object.
- Be creative, smart, and avoid repeating generic advice.
- Tailor everything to your performance data, test mistakes, and domain.
- Make the response sound like a mentor who cares and wants you to win.
`;


  try {
    const response = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "openai/gpt-3.5-turbo",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.7,
        max_tokens: 1200,
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
        },
      }
    );

    console.log("✅ AI insights response:", JSON.stringify(response.data, null, 2));

    const aiContent = response.data.choices[0]?.message?.content || "No insights available.";
    res.json({ insights: JSON.parse(aiContent) }); // Ensure it's parsed as JSON
  } catch (error) {
    console.error("❌ Error generating insights:", error.response?.data || error.message);
    res.status(500).json({ error: "Failed to generate insights" });
  }
});


const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
